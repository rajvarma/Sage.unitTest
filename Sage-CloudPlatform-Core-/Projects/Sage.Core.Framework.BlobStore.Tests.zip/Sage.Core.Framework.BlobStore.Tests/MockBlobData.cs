﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.Core.Framework.Storage;

namespace Sage.Core.Framework.BlobStore.Tests
{
    class MockBlobData : BaseBlobData<MockBlobData> 
    {
    }
}
