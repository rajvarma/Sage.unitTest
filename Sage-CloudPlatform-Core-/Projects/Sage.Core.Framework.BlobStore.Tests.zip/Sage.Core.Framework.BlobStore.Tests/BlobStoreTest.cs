﻿using System;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Sage.Core.Framework.Common;
using Sage.Core.Framework.Configuration;
using Sage.Core.Framework.Storage;
using System.IO;


namespace Sage.Core.Framework.BlobStore.Tests
{
    /// <summary>
    /// Summary description for BlobStoreTest
    /// </summary>
    [TestClass]
    public class BlobStoreTest
    {
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>

        #region Test methods

        [TestMethod]
        public void CanPut()
        {
            //mocking put method.
            _mockFactory.Verify(m => m.Put(streamBlobData));

            // Upload content to blob storage.
            _blob.Put(_context, streamBlobData);

            Assert.IsTrue(true);
        }

        [TestMethod]
        public void CanGet()
        {

            // Upload content to blob storage.
            _blob.Put(_context, streamBlobData);

            //Download a content from blob storage.
            _blob.Get(_context, streamBlobData);

            //mocking get method.
            _mockFactory.Verify(m => m.Get(streamBlobData));

            //Verifies that the specified condition is true
            Assert.IsTrue(true);
        }

        [TestMethod]
        public void CanDelete()
        {
           

            //Upload content to blob storage.
            _blob.Put(_context, streamBlobData);

            // Verifies that two  methods are equal.
            Assert.AreEqual(_mockFactory.Setup(m => m.Delete(streamBlobData)).Returns(true), _blob.Delete(_context, streamBlobData));

        }

        #endregion

        #region Additional test attributes

        /// <summary>
        /// Run windows azure emulator to do azure operation.
        /// </summary>
        [AssemblyInitialize]
        public static void BeforeAssembly(TestContext testContext)
        {
        }

        //{
        //    var process = Process.Start(@"C:\Program Files\Microsoft SDKs\Windows Azure\Emulator\csrun", "/devstore");
        //    if (process != null)
        //    {
        //        process.WaitForExit();
        //    }
        //    else
        //    {
        //        throw new ApplicationException("Unable to start storage emulator.");
        //    }
        //}

        /// <summary>
        /// Delete table from table storage.
        /// </summary>
        [TestCleanup]
        public void CleanupTest()
        {

        }

        /// <summary>
        ///  
        /// You can use the following additional attributes as you write your tests:
        ///
        /// Use ClassInitialize to run code before running the first test in the class
        /// </summary>
        [ClassInitialize]
        public static void BeforeTest(TestContext testContext)
        {
            SetUpBlobStore();

            //Create a mock factory.
            _mockFactory = GetMockedWorkUnit();

        }

        private static void SetUpBlobStore()
        {
            _configurationManager = new BaseConfigurationManager();
            // Set up mock context.
            _blob = new Storage.BlobStore(_configurationManager);
            _context = new Context();
        }

        private static Mock<BaseBlobStore> GetMockedWorkUnit()
        {
            return new Mock<BaseBlobStore>() {CallBase = true};
        }

        #endregion

        #region Properties

        private static Context _context;

        private static Mock<BaseBlobStore> _mockFactory;

        private static IConfigurationManager _configurationManager;

        private static IBlobStore _blob;

        private StreamBlob streamBlobData
        {
            get { return new StreamBlob {Name = Guid.NewGuid().ToString(), Path = "sagelabs", Content = new MemoryStream()}; }
        }

        #endregion
    }
}
